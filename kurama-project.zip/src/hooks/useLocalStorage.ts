import { useState, useEffect } from 'react';

export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T) => void] {
  // State untuk menyimpan nilai
  const [storedValue, setStoredValue] = useState<T>(initialValue);
  const [isInitialized, setIsInitialized] = useState(false);

  // Load dari localStorage saat mount
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    try {
      const item = window.localStorage.getItem(key);
      if (item) {
        setStoredValue(JSON.parse(item));
      }
      setIsInitialized(true);
    } catch (error) {
      console.error(`Error loading localStorage key "${key}":`, error);
      setIsInitialized(true);
    }
  }, [key]);

  // Return nilai yang sudah di-load atau initial value
  const valueToReturn = isInitialized ? storedValue : initialValue;

  // Setter function yang sync ke localStorage
  const setValue = (value: T) => {
    try {
      setStoredValue(value);
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, JSON.stringify(value));
      }
    } catch (error) {
      console.error(`Error saving localStorage key "${key}":`, error);
    }
  };

  return [valueToReturn, setValue];
}

export function clearLocalStorage() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('customerName');
    localStorage.removeItem('activeOrder');
    localStorage.removeItem('customerOrders');
    localStorage.removeItem('cartItems');
  }
}
